package com.example.conversor

import android.app.Activity
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.conversor.databinding.ActivityMainBinding
import android.content.Intent

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()

        setContentView(binding.root)

        binding.botaoDolar.setOnClickListener{
            val real : Double = binding.textoDeCima.text.toString().toDouble()
            val dolar = String.format("USD %.2f", real * 0.18)
            binding.textoEmBaixo.text = dolar.toString()
        }
        binding.botaoEuro.setOnClickListener{
            val real : Double = binding.textoDeCima.text.toString().toDouble()
            val euro = String.format("EUR %.2f", real * 0.16)
            binding.textoEmBaixo.text = euro.toString()
        }
        binding.botaoLibra.setOnClickListener{
            val real : Double = binding.textoDeCima.text.toString().toDouble()
            val libra = String.format("GBP %.2f", real * 0.14)
            binding.textoEmBaixo.text = libra.toString()
        }

        binding.trocarTela.setOnClickListener {
            val intent = Intent(this, CalculadoraActivity::class.java)
            startActivity(intent)
        }
    }
}