package com.example.conversor

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.conversor.databinding.ActivityCalculadoraBinding

class CalculadoraActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCalculadoraBinding // Declaração da binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityCalculadoraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.trocarTela2.setOnClickListener {
            finish() // Fecha a activity atual e volta para a anterior
        }

        binding.mais.setOnClickListener {
            val a : Double = binding.valorA.text.toString().toDouble()
            val b : Double = binding.valorB.text.toString().toDouble()
            val resultado1 : Double = a + b
            binding.resultado.text = resultado1.toString()
        }
        binding.menos.setOnClickListener {
            val a : Double = binding.valorA.text.toString().toDouble()
            val b : Double = binding.valorB.text.toString().toDouble()
            val resultado2 : Double = a - b
            binding.resultado.text = resultado2.toString()
        }
        binding.divisao.setOnClickListener {
            val a : Double = binding.valorA.text.toString().toDouble()
            val b : Double = binding.valorB.text.toString().toDouble()
            val resultado3 : Double = a / b
            binding.resultado.text = resultado3.toString()
        }
        binding.vezes.setOnClickListener {
            val a : Double = binding.valorA.text.toString().toDouble()
            val b : Double = binding.valorB.text.toString().toDouble()
            val resultado4 : Double = a * b
            binding.resultado.text = resultado4.toString()
        }

        }
    }